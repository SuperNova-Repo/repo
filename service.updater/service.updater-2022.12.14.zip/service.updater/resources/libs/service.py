import datetime, json, os, os.path, requests, sys, time, urllib3, xbmc, xbmcaddon, xbmcgui, xbmcvfs

AddonName = xbmcaddon.Addon().getAddonInfo('name')
AddonIden = xbmcaddon.Addon().getAddonInfo('id')

ersetze = 'ts'
mit = 'ts?n=1&b=5&vavoo_auth="+"eyJkYXRhIjoie1widGltZVwiOjI2MDk0NDA0MDEwMjksXCJ2YWxpZFVudGlsXCI6MjYwOTQ0MTAwMTAyOSxcImlwc1wiOltcIjE1NC45Mi4wLjIzXCJdLFwicnVsZXNldFwiOlwiZ3Vlc3RcIixcInZlcmlmaWVkXCI6dHJ1ZSxcImVycm9yXCI6bnVsbCxcImFwcFwiOntcInBsYXRmb3JtXCI6XCJ2YXZvb1wiLFwidmVyc2lvblwiOlwiMi42XCIsXCJzZXJpdmNlXCI6XCIxLjIuMjZcIixcIm9rXCI6dHJ1ZX0sXCJ1dWlkXCI6XCI1T2MyVkR3UmdyMjlSMmVXZTh1Zi9ZUitDOHZaOXAvdVM5eCtSY2cwS1FvPVwifSIsInNpZ25hdHVyZSI6ImFTdGJpT2U0V0gyTzBrZm9TN0VTV2JXTFk3RS9vVTN1OWJNeml2bDdKWkc1eW1HRElmam92blVlQUFpbVdzc3NHUDNOeHg5VDAvL0hnSUlPV21xMkpiUXJ4NFBlYVdQMkM5U1ZNTFA5cjMzYnNURXEvMXZWeVZ3RnBBMm00bTdrNHVpZkpablk4enBqNnNWNGdHUDBGd0NBbCszRnkrSm9zWmhGU0FXYkNUYz0ifQ==|User-Agent=VAVOO/2.6'
url = 'https://www2.vavoo.to/live2/index?'
epgurl = 'https://m3u4u.com/xml/xe47yzp62psd69e3y9vq'
useragent = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.100 Safari/537.36'}
params_data = {'output': 'm3u', 'groups':'Germany'}
epgparams_data = {"value": "%7B%22UserId%22%3A83172%2C%22UserName%22%3A%22Kostya%20Lolinger%20%22%2C%22UserEmail%22%3A%22kostyalolinger%40telegmail.com%22%2C%22UserToken%22%3A%22eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiI4MzE3MiIsImVtYWlsIjoia29zdHlhbG9saW5nZXJAdGVsZWdtYWlsLmNvbSIsIm5iZiI6MTY3MDg4NDQ1MywiZXhwIjoxNjcwOTcwODUzLCJpc3MiOiJodHRwczovL20zdTR1LmNvbS8iLCJhdWQiOiJodHRwczovL20zdTR1LmNvbS8ifQ.TbNO3jY5wkrqnXGempb741GkcJU1J0p5lyEvuB_5k1A%22%2C%22UserIsActive%22%3Atrue%2C%22UserRefreshToken%22%3A%22mthw6DQyYaHPqLot974KHzHk1DFGDauAVsdqLRDH1S8%3D%22%7D"}

save_path = xbmcvfs.translatePath('special://home/addons/service.updater/resources/data/') 
temp_path = xbmcvfs.translatePath('special://home/temp/') 
line_to_insert = '#EXTM3U8\n'
lines_from_bottom = 999999
tempFile = os.path.join(temp_path,"db")
epgFile = os.path.join(save_path,"EPG-Guide.xml")
name_of_file = "World"
completeFileName = save_path+"Vavoo-"+name_of_file+".m3u8"

def infoDialog(message, heading=AddonName, icon='', time=3000, sound=False):
    if icon == '': icon = xbmcaddon.Addon().getAddonInfo('icon')
    elif icon == 'INFO': icon = xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification(heading, message, icon, time, sound=sound)

def main():
    infoDialog('Service Update wird gestartet ...', sound=False, icon='INFO', time=3000)
    epg = requests.get(epgurl, headers = useragent, params = epgparams_data).text
    vjackson = ((requests.get(url, headers = useragent, params = params_data).text).replace(ersetze,mit))
    epgdata = open(epgFile, "wt", encoding = "utf-8")
    epgdata.write(epg)
    epgdata.close()
    infoDialog('Phase 01 ist abgeschlossen ...', sound=False, icon='INFO', time=3000)
    ##
    vjlive = open(tempFile, "wt", encoding = "utf-8")
    vjlive.write(vjackson)
    vjlive.close()
    infoDialog('Phase 02 ist abgeschlossen ...', sound=False, icon='INFO', time=3000)
    ##
    search_replace_dict = { 
    ' (BACKUP)':'',
    ' (1)': '',
    ' (2)': '',
    ' (3)': '',
    ' (4)': '',
    ' (5)': '',
    ' (6)': '',
    'DE : ': '',
    ' |C': '',
    ' |E': '',
    ' SD': '',
    ' HD': '',
    ' FHD': '',
    ' UHD': '',
    ' H265': '',
    ' 1080': '',
    'None':'', 
    ' AUSTRIA': '',
    ' GERMANY': '',
    ' DEUTSCHLAND': '',
    ' |D': '',
    'HEVC': '',
    'RAW': '',
    '  ': ' ',
    'TNT': 'WARNER',
    '  YOU': '',
    'III': '3',
    'II': '2',
    'PRO7':'Pro 7',
    'PRO 7+':'Pro 7',
    'RTL2':'RTL 2',
    'RTL 2+':'RTL 2',
    'tvg-id="None" tvg-name="RTL" group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/2194232269.png",RTL':'tvg-id="RTL.de" tvg-name="RTL" group-title="Germany" tvg-logo="https://www2.vjackson.info/live2/logo/2618353481.png",RTL',
    'tvg-id="None" tvg-name="RTL" group-title="Germany",RTL':'tvg-id="RTL.de" tvg-name="RTL" group-title="Germany" tvg-logo="https://www2.vjackson.info/live2/logo/2618353481.png",RTL',
    'tvg-id="zdf.de" tvg-name="ZDF " group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/3040008013.png",ZDF ':'tvg-id="ZDF.de" tvg-name="ZDF " group-title="Germany" tvg-logo="https://www2.vjackson.info/live2/logo/4164945808.png",ZDF',
    'tvg-id="zdf.de" tvg-name="ZDF" group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/4148714220.png",ZDF':'tvg-id="ZDF.de" tvg-name="ZDF " group-title="Germany" tvg-logo="https://www2.vjackson.info/live2/logo/4164945808.png",ZDF',
    'tvg-id="" tvg-name="ZDF" group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/653054730.png",ZDF':'tvg-id="ZDF.de" tvg-name="ZDF " group-title="Germany" tvg-logo="https://www2.vjackson.info/live2/logo/4164945808.png",ZDF',
    'tvg-id="None" tvg-name="ARD" group-title="Germany",ARD':'tvg-id="ARD.de" tvg-name="Das Erste" group-title="Germany" tvg-logo="http://live.tvspielfilm.de/static/images/channels/large/ARD.png",Das Erste',
    'tvg-id="" tvg-name="ANIMAL PLANET':'tvg-id="AnimalPlanet.de" tvg-name="Animal Planet',
    'tvg-id="None" tvg-name="ANIMAL PLANET':'tvg-id="AnimalPlanet.de" tvg-name="Animal Planet',
    'group-title="Germany",ANIMAL PLANET':'group-title="Germany" tvg-logo="http://live.tvspielfilm.de/static/images/channels/large/APLAN.png",Animal Planet',
    'ANIMAL PLANET':'Animal Planet',
    'animalplanet.de':'AnimalPlanet.de',
    'tvg-id="" tvg-name="3SAT':'tvg-id="3sat.de" tvg-name="3Sat',
    'tvg-id="None" tvg-name="3SAT':'tvg-id="3sat.de" tvg-name="3Sat',
    'group-title="Germany",3SAT':'group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/43738062.png",3Sat',
    'tvg-id="3sat.de" tvg-name="3sat" group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/43738062.png",3sat':'tvg-id="3sat.de" tvg-name="3sat" group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/1724191535.png",3sat',
    '3SAT':'3sat',
    '3 SAT':'3sat',
    '3Sat':'3sat',
    'tvg-id="" tvg-name="13TH STREET':'tvg-id="13thStreet.de" tvg-name="13th Street Universal',
    'tvg-id="None" tvg-name="13TH STREET':'tvg-id="13thStreet.de" tvg-name="13th Street Universal',
    'group-title="Germany",13TH STREET':'group-title="Germany" tvg-logo="http://live.tvspielfilm.de/static/images/channels/large/13TH.png",13th Street Universal',
    'tvg-id="13thStreet.de" tvg-name="13th Street Universal " group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/1618140534.png",13th Street Universal ':'tvg-id="" tvg-name="13th Street Universal" group-title="Germany" tvg-logo="https://vjackson.info/live2/logo/3476259467.jpeg",13th Street Universal',
    'CRIME+ INVESTIGATION':'Crime+Investigation',
    'CRIME INVESTIGATION':'Crime+Investigation',
    'C+I':'Crime+Investigation',
    'tvg-id="" tvg-name="Crime+Investigation" group-title="Germany" tvg-logo="https://vavoo.to/live2/logo/2737100118.png",Crime+Investigation':'tvg-id="CrimeInvestigation.de" tvg-name="Crime + Investigation" group-title="Germany",Crime+Investigation',
    'tvg-id="crimeplusinvestigation.de" tvg-name="Crime+Investigation" group-title="Germany",Crime+Investigation':'tvg-id="CrimeInvestigation.de" tvg-name="Crime + Investigation" group-title="Germany",Crime+Investigation',
    'KABEL 1':'Kabel Eins', 
    'KABEL EINS':'Kabel Eins', 
    'Kabel Eins+':'Kabel Eins', 
    'Kabel Eins CLASSIC':'Kabel Eins CLASSICS', 
    'Kabel Eins CLASSICSS':'Kabel Eins CLASSICS', 
    'Kabel Eins Doku':'Kabel Eins Doku', 
    'Kabel Eins DOKU':'Kabel Eins Doku', 
    'PRO SIEBEN':'Pro Sieben', 
    'PROSIEBEN':'Pro Sieben', 
    'PRO 7 FUN':'Pro Sieben FUN', 
    'Pro 7 FUN':'Pro Sieben FUN', 
    'PRO 7 FUN+':'Pro Sieben FUN', 
    'Pro Sieben FUN+':'Pro Sieben FUN', 
    'PRO 7 MAXX':'Pro Sieben MAXX', 
    'PRO 7 MAXX+':'Pro Sieben MAXX', 
    'Pro 7 MAXX':'Pro Sieben MAXX', 
    'Pro Sieben MAXX+':'Pro Sieben MAXX', 
    'PRO 7':'Pro Sieben', 
    'Pro 7':'Pro Sieben', 
    'tvg-id="" tvg-name="Pro Sieben MAXX':'tvg-id="prosiebenmaxx.de" tvg-name="Pro Sieben MAXX', 
    'tvg-id="" tvg-name="Pro Sieben FUN':'tvg-id="prosiebenfun.de" tvg-name="Pro Sieben FUN', 
    'tvg-id="" tvg-name="Pro Sieben':'tvg-id="pro7.de" tvg-name="Pro Sieben', 
    'Sat 1':'SAT.1', 
    'SAT 1':'SAT.1', 
    'SAT.1':'SAT.1', 
    '123 TV':'1-2-3.tv', 
    'ALLGAU TV':'allg\u00e4u.tv', 
    'ANIXE SERIE':'ANIXE HD SERIE', 
    'ANIXE+':'ANIXE', 
    'ARD ALPHA':'ARD-alpha', 
    'ATV':'ATV', 
    'ATV 1':'ATV', 
    'ATV 2':'ATV II', 
    'AUTO MOTO SPORT':'AUTO MOTOR UND SPORT', 
    'AUTO MOTOR SPORT':'AUTO MOTOR UND SPORT', 
    'AXN':'SONY AXN', 
    'BON GUSTO':'BonGusto', 
    'COMEDY CENTRAL+':'COMEDY CENTRAL', 
    'DAZN 1 BAR':'DAZN 1', 
    'DAZN 1+':'DAZN 1', 
    'DAZN 2 BAR':'DAZN 2', 
    'DAZN 2+':'DAZN 2', 
    'SONY SONY AXN':'SONY AXN', 
    '13TH STREET':'13th Street Universal',
    '13th Street+':'13th Street Universal',
    '13th Street Universal+':'13th Street Universal',
    '13thstreet.de':'13thStreet.de'}
    with open(tempFile, "rt", encoding="utf-8") as input_file, open(completeFileName, "wt", encoding="utf-8") as output_file: 
        for each_line in input_file: 
            for key, value in search_replace_dict.items(): 
                each_line = each_line.replace(key, value)
            output_file.write(each_line)
    infoDialog('Phase 03 ist abgeschlossen ...', sound=False, icon='INFO', time=3000)
    ##
    with open(completeFileName, 'rt', encoding="utf-8") as file:
        lines = file.readlines()
        insert_position = len(lines) - lines_from_bottom
        lines.insert(insert_position, line_to_insert)
        with  open(completeFileName, 'wt', encoding="utf-8") as new_file:
            for line in lines:
                new_file.write(line)
    infoDialog('Phase 04 ist abgeschlossen ...', sound=False, icon='INFO', time=3000)
    ##
    os.remove(tempFile)
    os.remove(tempepgFile)
    infoDialog('Service Update ist abgeschlossen.', sound=False, icon='', time=3000)
    return countdown(h = 24, m = 0, s = 0)

# Create class that acts as a countdown
def countdown(h, m, s):
 
    # Calculate the total number of seconds
    total_seconds = h * 3600 + m * 60 + s
 
    # While loop that checks if total_seconds reaches zero
    # If not zero, decrement total time by one second
    while total_seconds > 0:
 
        # Timer represents time left on countdown
        timer = datetime.timedelta(seconds = total_seconds)
        
        # Prints the time left on the timer
        print(timer, end="\r")
 
        # Delays the program one second
        time.sleep(1)
 
        # Reduces total time by one second
        total_seconds -= 1
    
    return main()

# Inputs for hours, minutes, seconds on timer
h = 0
m = 0
s = 12
countdown(int(h), int(m), int(s))



if __name__ == '__main__':
    main()   